package pet_treasure_Model;

import java.util.ArrayList;
import java.util.List;

public class Constants {

    public List<String> userName = new ArrayList<String>();




}
